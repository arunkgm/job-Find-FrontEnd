import React from "react";
import Navigation from "../components/Navigation";
import JobMap from "../components/JobMap";
import "../StyleSheet/Home.css";

// first create fun 

function Home() {
  return (
    <>   
    <Navigation/>   
      <JobMap />
      </>

  );
}
export default Home;
